#### Set up
`npm i` cho từng folder frontend và backend

#### Run
Frontend: ng serve
Backend: npm start run:dev 
